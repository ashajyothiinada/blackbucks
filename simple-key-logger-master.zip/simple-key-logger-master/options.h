#ifndef _OPTIONS_H_
#define _OPTIONS_H_

#include "config.h"

void parseOptions(int argc, char **argv, Config *config);

#endif